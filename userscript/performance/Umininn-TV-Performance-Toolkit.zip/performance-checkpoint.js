(async function () {
    'use strict';
    if (location.protocol !== 'https:' || location.hostname !== 'umininn-gh.github.io' || !location.pathname.startsWith('/tv/')) {
        alert('請先回到 Umininn TV 觀看頁，再執行「TV 效能檢查」書籤。'); return;
    }
    const pane = document.getElementById('multi-stream-container');
    if (!pane) { alert('此頁沒有播放器容器。'); return; }
    const tiles = [...pane.children].slice(0, 256), root = document.documentElement;
    const version = root.getAttribute('data-umininn-player-userscript');
    const identities = [], placements = [], nativeAudioSettings = [], hosts = new Map();
    const native = { count: 0, playing: 0, paused: 0, errored: 0, muted: 0, audible: 0 };
    for (const tile of tiles) {
        const key = tile.getAttribute('data-channel-key') || '';
        identities.push(key);
        const rect = tile.getBoundingClientRect(), style = getComputedStyle(tile);
        placements.push([key, style.order, style.gridArea, Math.round(rect.left), Math.round(rect.top), Math.round(rect.width), Math.round(rect.height)]);
        const frames = tile.tagName === 'IFRAME' ? [tile] : [...tile.querySelectorAll('iframe')];
        for (const frame of frames) {
            try { const host = new URL(frame.getAttribute('src') || '', location.href).hostname; if (host) hosts.set(host, (hosts.get(host) || 0) + 1); } catch (_) {}
        }
        const media = tile.matches('video,audio') ? [tile] : [...tile.querySelectorAll('video,audio')];
        for (const [index, item] of media.entries()) {
            native.count++;
            if (!item.paused && !item.ended && item.readyState >= 2) native.playing++;
            if (item.paused) native.paused++;
            if (item.error) native.errored++;
            if (item.muted) native.muted++;
            if (!item.muted && item.volume > 0 && !item.paused && !item.ended && item.readyState >= 2) native.audible++;
            nativeAudioSettings.push([key, index, item.muted, Math.round(item.volume * 1000) / 1000]);
        }
    }
    async function digest(value) {
        if (!crypto.subtle) return null;
        const bytes = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(value))));
        return [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
    }
    const data = {
        schema: 'umininn-tv-performance-checkpoint/1', createdAt: new Date().toISOString(),
        userscriptVersion: /^\d+(\.\d+){1,3}$/.test(version || '') ? version : null,
        controls: { audioFocus: root.hasAttribute('data-umininn-player-audio-focus-ready'), unifiedAudio: root.hasAttribute('data-umininn-player-unified-audio-ready') },
        page: location.origin + location.pathname, browserUserAgent: navigator.userAgent,
        documentHidden: document.hidden, tileCount: tiles.length,
        channelSetSha256: identities.every(Boolean) ? await digest(identities.slice().sort()) : null,
        layoutSha256: identities.every(Boolean) ? await digest(placements) : null,
        nativeAudioSha256: identities.every(Boolean) ? await digest(nativeAudioSettings) : null,
        nativeMedia: native, frameHosts: [...hosts].map(([host, count]) => ({ host, count }))
    };
    // One tiny Blob is retained until the next checkpoint or navigation. There
    // are no observers, event subscriptions, sampling intervals or upload.
    if (window.__umininnPerformanceCheckpointUrl) URL.revokeObjectURL(window.__umininnPerformanceCheckpointUrl);
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    window.__umininnPerformanceCheckpointUrl = url;
    const link = document.createElement('a'); link.href = url;
    link.download = 'umininn-tv-perf-checkpoint-' + data.createdAt.replace(/[:.]/g, '-') + '.json';
    link.click();
})();
