﻿[CmdletBinding()]
param(
    [ValidateSet('Firefox', 'Chrome', 'Edge')][string]$Browser = 'Firefox',
    [ValidateRange(1, 240)][int]$Minutes = 30,
    [ValidateSet(5, 10)][int]$SampleSeconds = 5,
    [ValidateRange(0, 600)][int]$WarmupSeconds = 60,
    [string]$ExpectedOnVersion,
    [string]$OutputRoot
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Performance-Core.ps1')
if (-not $OutputRoot) { $OutputRoot = Join-Path $PSScriptRoot 'results' }
$runFolder = Join-Path $OutputRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 6))
[IO.Directory]::CreateDirectory($runFolder) | Out-Null
$run = [ordered]@{
    schema = 'umininn-tv-target-performance/1'
    createdAt = [DateTime]::UtcNow.ToString('o')
    updatedAt = $null
    browser = $Browser
    processNames = @(Get-TVProcessNames $Browser)
    hostInfo = Get-TVHostInfo
    requestedMinutesPerPhase = $Minutes
    warmupSeconds = $WarmupSeconds
    sampleSeconds = $SampleSeconds
    expectedOnVersion = $ExpectedOnVersion
    phases = @()
    comparison = $null
    status = 'preparing'
    error = $null
    privacy = 'No cookies, credentials, browser command lines, native stream URLs, chat contents, network capture or remote upload. Only the supplied checkpoint files and selected browser process counters are read.'
    limitations = @(
        'All matching browser processes are included, not just the viewing tab.',
        'Short-lived processes can exit between samples; their final CPU tail may be missed.',
        'Sequential live-site conditions can differ due to ads, quality changes, stream failures and background activity.',
        'Cross-origin video frame rate and decoded playback cannot be inspected by this dependency-free sampler.',
        'CPU and memory measurements do not by themselves prove a memory leak or establish causality.'
    )
}

function Read-TVCheckpointInteractive {
    param([string]$Mode, [string]$Position, [DateTime]$Earliest)
    while ($true) {
        Write-Host ''
        Write-Host ('請回觀看頁執行「TV 效能檢查」書籤，下載 {0} / {1} 檢查點。' -f $Mode, $Position) -ForegroundColor Cyan
        Write-Host '完成後回本視窗：Enter 搜尋 Downloads 內本工具的最新檔案；B 選擇檔案；Q 停止。'
        $answer = Read-Host
        if ($answer -match '^[qQ]$') { throw [OperationCanceledException]::new('User cancelled checkpoint selection.') }
        $checkpointPath = $null
        if ($answer -match '^[bB]$') {
            try {
                Add-Type -AssemblyName System.Windows.Forms
                $picker = New-Object System.Windows.Forms.OpenFileDialog
                $picker.Title = '選擇 umininn-tv-perf-checkpoint-….json'
                $picker.Filter = 'TV performance checkpoint (*.json)|*.json'
                if ($picker.ShowDialog() -eq [Windows.Forms.DialogResult]::OK) { $checkpointPath = $picker.FileName }
                $picker.Dispose()
            } catch { Write-Host ('檔案選擇器未能開啟：' + $_.Exception.Message) -ForegroundColor Yellow }
        } elseif ($answer.Trim()) {
            Write-Host '請按 Enter、B 或 Q。' -ForegroundColor Yellow
            continue
        } else {
            $downloads = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
            $latest = @(Get-ChildItem -LiteralPath $downloads -Filter 'umininn-tv-perf-checkpoint-*.json' -File -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTimeUtc -ge $Earliest } | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1)
            if ($latest.Count) { $checkpointPath = $latest[0].FullName }
        }
        if (-not $checkpointPath) { Write-Host '未找到新的檢查點。若使用自訂下載資料夾，請按 B。' -ForegroundColor Yellow; continue }
        try {
            $checkpoint = ConvertTo-TVCheckpoint $checkpointPath
            $issues = @(Test-TVCheckpoint $checkpoint $Mode $Browser $Earliest $ExpectedOnVersion)
            if ($issues.Count) {
                foreach ($issue in $issues) { Write-Host $issue -ForegroundColor Yellow }
                continue
            }
            Write-TVUtf8 (Join-Path $runFolder ($Mode + '-' + $Position + '-checkpoint.json')) ($checkpoint | ConvertTo-Json -Depth 8)
            Write-Host ('已核對：{0} 台；腳本版本 {1}。' -f $checkpoint.tileCount, $(if ($checkpoint.userscriptVersion) { $checkpoint.userscriptVersion } else { '關閉' })) -ForegroundColor Green
            return $checkpoint
        } catch { Write-Host ('檢查檔無效：' + $_.Exception.Message) -ForegroundColor Yellow }
    }
}

try {
    Write-Host 'Umininn TV 目標電腦效能對照工具' -ForegroundColor Cyan
    Write-Host '只讀取瀏覽器處理程序數字，不會自動切換腳本、登入、關格或上傳。'
    Write-Host '量測範圍是整個所選瀏覽器。請盡量只留下測試用的視窗／分頁；其他工作可使用另一款瀏覽器。'
    Write-Host '請先開 start.html，將「TV 效能檢查」連結加入書籤。'
    if (-not $PSBoundParameters.ContainsKey('Browser')) {
        $choice = Read-Host '目標瀏覽器：1 Firefox（預設）／2 Chrome／3 Edge'
        switch ($choice) { '2' { $Browser = 'Chrome' }; '3' { $Browser = 'Edge' }; '' {}; '1' {}; default { throw '請重新執行並選擇 1、2 或 3。' } }
        $run.browser = $Browser
        $run.processNames = @(Get-TVProcessNames $Browser)
    }
    if (-not $PSBoundParameters.ContainsKey('Minutes')) {
        $choice = Read-Host '每段採樣分鐘（預設 30；可輸入 1–240）'
        if ($choice) {
            $parsed = 0
            if (-not [int]::TryParse($choice, [ref]$parsed) -or $parsed -lt 1 -or $parsed -gt 240) { throw '分鐘數無效。' }
            $Minutes = $parsed; $run.requestedMinutesPerPhase = $Minutes
        }
    }
    Write-Host ('瀏覽器 {0}；每段 {1} 分鐘；暖機 {2} 秒；每 {3} 秒採樣。' -f $Browser, $Minutes, $WarmupSeconds, $SampleSeconds)
    Write-Host ('結果資料夾：' + $runFolder)
    Write-Host '為了可比較：兩段保留相同台、畫質、大小、硬體加速與音量；避免切台、下載或開新分頁。'
    Write-Host '採樣時請回到觀看頁保持前景，不要把瀏覽器最小化。可回本視窗按 Q 安全結束並保存。'
    foreach ($mode in @('off', 'on')) {
        Write-Host ''
        if ($mode -eq 'off') {
            Write-Host '第一段：在 Tampermonkey 停用播放器 userscript，再重新整理觀看頁。' -ForegroundColor Cyan
        } else {
            Write-Host '第二段：在 Tampermonkey 啟用播放器 userscript，再重新整理觀看頁，還原同一台分佈與畫質。' -ForegroundColor Cyan
        }
        $phase = [ordered]@{
            mode = $mode; status = 'preparing'; sampleSeconds = $SampleSeconds; requestedSeconds = $Minutes * 60
            startedAt = $null; endedAt = $null; actualWallSeconds = 0; initialPrivateBytes = 0
            startCheckpoint = $null; endCheckpoint = $null; summary = $null; rows = @()
        }
        $run.phases += $phase
        Save-TVRun $run $runFolder
        $phase.startCheckpoint = Read-TVCheckpointInteractive $mode 'start' ([DateTime]::UtcNow.AddMinutes(-10))
        $initial = Get-TVProcessSnapshot $run.processNames
        if ($initial.processCount -eq 0) { throw ('找不到 {0} 處理程序，請檢查瀏覽器選擇。' -f $Browser) }
        Write-Host ('開始 {0} 秒暖機，現在請切回觀看頁。' -f $WarmupSeconds) -ForegroundColor Green
        $run.status = 'recording'
        Invoke-TVPhase -Run $run -Phase $phase -Folder $runFolder -ProcessNames $run.processNames -DurationSeconds ($Minutes * 60) -WarmupSeconds $WarmupSeconds -SampleSeconds $SampleSeconds
        if ($phase.status -eq 'cancelled') { $run.status = 'cancelled'; break }
        Write-Host ('階段 {0} 已完成；實測 {1:N1} 秒。' -f $mode, $phase.summary.actualSampledSeconds) -ForegroundColor Green
        $phase.endCheckpoint = Read-TVCheckpointInteractive $mode 'end' ([DateTime]::Parse($phase.endedAt).ToUniversalTime().AddSeconds(-5))
        Save-TVRun $run $runFolder
    }
    if ($run.status -ne 'cancelled') { $run.status = 'complete' }
} catch [OperationCanceledException] {
    $run.status = 'cancelled'
    $run.error = 'User cancelled.'
} catch {
    $run.status = 'error'
    $run.error = $_.Exception.Message
    Write-Host ('已停止：' + $_.Exception.Message) -ForegroundColor Red
} finally {
    try { Save-TVRun $run $runFolder } catch { Write-Host ('報告儲存問題：' + $_.Exception.Message) -ForegroundColor Red }
    Write-Host ''
    Write-Host ('資料已保存於：' + $runFolder) -ForegroundColor Cyan
    Write-Host '請提供整個結果資料夾。summary.json 是分析入口；samples.csv／processes.csv 保留原始數據。'
    Write-Host 'report.html 可以直接開啟查看摘要。結果不會自動上傳。'
    [void](Read-Host '按 Enter 關閉')
}
