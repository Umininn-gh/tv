﻿# Read-only browser process sampling. Windows PowerShell 5.1 compatible.
Set-StrictMode -Version 2

function Get-TVField {
    param($Object, [string]$Name, $Default = $null)
    if ($null -eq $Object) { return $Default }
    if ($Object -is [System.Collections.IDictionary]) {
        if ($Object.Contains($Name)) { return $Object[$Name] }
        return $Default
    }
    if ($null -ne $Object.PSObject.Properties[$Name]) { return $Object.$Name }
    return $Default
}

function Write-TVUtf8 {
    param([string]$Path, [string]$Text)
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($true)))
}

function Get-TVProcessNames {
    param([ValidateSet('Firefox', 'Chrome', 'Edge')][string]$Browser)
    switch ($Browser) {
        'Firefox' { return @('firefox', 'plugin-container') }
        'Chrome' { return @('chrome') }
        'Edge' { return @('msedge') }
    }
}

function Get-TVHostInfo {
    $cpuName = 'Unavailable'
    try { $cpuName = [string](Get-ItemProperty -LiteralPath 'HKLM:\HARDWARE\DESCRIPTION\System\CentralProcessor\0' -ErrorAction Stop).ProcessorNameString } catch {}
    return [ordered]@{
        logicalCpuCount = [Environment]::ProcessorCount
        cpuModel = $cpuName.Trim()
        operatingSystem = [Environment]::OSVersion.VersionString
        powershellVersion = $PSVersionTable.PSVersion.ToString()
        processArchitecture = $(if ([Environment]::Is64BitProcess) { '64-bit' } else { '32-bit' })
        scope = 'All processes with the selected exact browser names, including its other windows/profiles. Not a single tab.'
        cpuDefinition = '100 percent = one logical CPU core; hostCapacityPercent divides by logical CPU count.'
        memoryDefinition = 'PrivateBytes is committed private process memory; WorkingSetBytes is resident memory and may double-count shared pages.'
    }
}

function Get-TVProcessSnapshot {
    param([string[]]$ProcessNames)
    $items = New-Object System.Collections.Generic.List[object]
    $unreadable = 0
    $found = @(Get-Process -Name $ProcessNames -ErrorAction SilentlyContinue)
    foreach ($process in $found) {
        try {
            $process.Refresh()
            $item = [ordered]@{
                id = $process.Id
                name = $process.ProcessName
                startUtc = $process.StartTime.ToUniversalTime().ToString('o')
                cpuSeconds = [double]$process.TotalProcessorTime.TotalSeconds
                privateBytes = [long]$process.PrivateMemorySize64
                workingSetBytes = [long]$process.WorkingSet64
            }
            if (-not ($ProcessNames -contains [string]$item.name)) { continue }
            $items.Add([pscustomobject]$item)
        } catch { $unreadable++ }
    }
    $private = [long]0
    $resident = [long]0
    foreach ($item in $items) { $private += $item.privateBytes; $resident += $item.workingSetBytes }
    return [pscustomobject][ordered]@{
        observedAtUtc = [DateTime]::UtcNow.ToString('o')
        monotonicSeconds = [double][Diagnostics.Stopwatch]::GetTimestamp() / [Diagnostics.Stopwatch]::Frequency
        processCount = $items.Count
        unreadableProcesses = $unreadable
        privateBytes = $private
        workingSetBytes = $resident
        processes = @($items.ToArray())
    }
}

function Get-TVDelta {
    param($Previous, $Current, [int]$LogicalCpuCount)
    $elapsed = [double]$Current.monotonicSeconds - [double]$Previous.monotonicSeconds
    if ($elapsed -le 0) { throw 'The monotonic clock did not advance.' }
    $before = @{}
    $after = @{}
    foreach ($item in $Previous.processes) { $before[('{0}|{1}' -f $item.id, $item.startUtc)] = $item }
    $cpu = [double]0
    $newProcesses = 0
    $unmatchedExisting = 0
    foreach ($item in $Current.processes) {
        $identity = '{0}|{1}' -f $item.id, $item.startUtc
        $after[$identity] = $true
        if ($before.ContainsKey($identity)) {
            $change = [double]$item.cpuSeconds - [double]$before[$identity].cpuSeconds
            if ($change -ge 0) { $cpu += $change } else { $unmatchedExisting++ }
        } else {
            $newProcesses++
            $start = [DateTime]::Parse($item.startUtc).ToUniversalTime()
            $previousUtc = [DateTime]::Parse($Previous.observedAtUtc).ToUniversalTime()
            if ($start -ge $previousUtc) { $cpu += [Math]::Max(0, [double]$item.cpuSeconds) }
            else { $unmatchedExisting++ }
        }
    }
    $exited = 0
    foreach ($identity in $before.Keys) { if (-not $after.ContainsKey($identity)) { $exited++ } }
    return [pscustomobject][ordered]@{
        elapsedSeconds = $elapsed
        cpuSeconds = $cpu
        cpuCorePercent = 100 * $cpu / $elapsed
        cpuHostCapacityPercent = 100 * $cpu / $elapsed / [Math]::Max(1, $LogicalCpuCount)
        newProcesses = $newProcesses
        exitedProcesses = $exited
        unmatchedExistingProcesses = $unmatchedExisting
    }
}

function Get-TVMean {
    param([object[]]$Values)
    if ($Values.Count -eq 0) { return $null }
    $sum = [double]0
    foreach ($value in $Values) { $sum += [double]$value }
    return $sum / $Values.Count
}

function Get-TVPhaseSummary {
    param($Phase, [int]$LogicalCpuCount)
    $rows = @($Phase.rows)
    if ($rows.Count -eq 0) { return $null }
    $elapsed = [double]0
    $cpu = [double]0
    $peakPrivate = [long]0
    $peakResident = [long]0
    $gaps = 0
    $missing = 0
    $unreadable = 0
    $exited = 0
    $unmatched = 0
    foreach ($row in $rows) {
        $elapsed += [double]$row.intervalSeconds
        $cpu += [double]$row.cpuSeconds
        $peakPrivate = [Math]::Max($peakPrivate, [long]$row.privateBytes)
        $peakResident = [Math]::Max($peakResident, [long]$row.workingSetBytes)
        if ($row.intervalSeconds -gt ([double]$Phase.sampleSeconds * 3)) { $gaps++ }
        if ($row.processCount -eq 0) { $missing++ }
        $unreadable += [int]$row.unreadableProcesses
        $exited += [int]$row.exitedProcesses
        $unmatched += [int]$row.unmatchedExistingProcesses
    }
    $firstPrivate = [long]$Phase.initialPrivateBytes
    $lastPrivate = [long]$rows[-1].privateBytes
    $meanPrivate = Get-TVMean @($rows | ForEach-Object { $_.privateBytes })
    $meanResident = Get-TVMean @($rows | ForEach-Object { $_.workingSetBytes })
    return [ordered]@{
        actualSampledSeconds = [Math]::Round($elapsed, 3)
        sampleCount = $rows.Count
        cpuCorePercent = [Math]::Round((100 * $cpu / [Math]::Max(0.001, $elapsed)), 3)
        cpuHostCapacityPercent = [Math]::Round((100 * $cpu / [Math]::Max(0.001, $elapsed) / [Math]::Max(1, $LogicalCpuCount)), 3)
        averagePrivateMiB = [Math]::Round($meanPrivate / 1MB, 3)
        initialPrivateMiB = [Math]::Round($firstPrivate / 1MB, 3)
        lastPrivateMiB = [Math]::Round($lastPrivate / 1MB, 3)
        privateGrowthMiB = [Math]::Round(($lastPrivate - $firstPrivate) / 1MB, 3)
        peakPrivateMiB = [Math]::Round($peakPrivate / 1MB, 3)
        averageWorkingSetMiB = [Math]::Round($meanResident / 1MB, 3)
        peakWorkingSetMiB = [Math]::Round($peakResident / 1MB, 3)
        samplingGaps = $gaps
        noBrowserSamples = $missing
        unreadableProcessObservations = $unreadable
        exitedProcessObservations = $exited
        unmatchedExistingProcessObservations = $unmatched
        trendInterpretation = 'Memory growth is not proof of a leak; video buffers, browser caches and other tabs also affect these process totals.'
        longDuration = ($elapsed -ge 600)
    }
}

function ConvertTo-TVCheckpoint {
    param([string]$Path)
    $file = Get-Item -LiteralPath $Path -ErrorAction Stop
    if ($file.Length -gt 65536) { throw 'Checkpoint is unexpectedly large.' }
    $value = [IO.File]::ReadAllText($file.FullName) | ConvertFrom-Json -ErrorAction Stop
    if ((Get-TVField $value 'schema') -ne 'umininn-tv-performance-checkpoint/1') { throw 'This is not a TV performance checkpoint.' }
    $version = Get-TVField $value 'userscriptVersion'
    if ($null -ne $version -and ([string]$version -notmatch '^\d+(\.\d+){1,3}$')) { throw 'Invalid userscript version.' }
    $stamp = [DateTime]::Parse([string](Get-TVField $value 'createdAt')).ToUniversalTime()
    $uri = New-Object Uri([string](Get-TVField $value 'page'))
    if ($uri.Scheme -ne 'https' -or $uri.Host -ne 'umininn-gh.github.io' -or -not $uri.AbsolutePath.StartsWith('/tv/')) { throw 'Checkpoint must come from the Umininn TV viewing page.' }
    $count = Get-TVField $value 'tileCount'
    if ($null -eq $count -or [int]$count -lt 1 -or [int]$count -gt 256) { throw 'Checkpoint has an invalid player count.' }
    $flags = Get-TVField $value 'controls'
    foreach ($name in @('audioFocus', 'unifiedAudio')) {
        if ((Get-TVField $flags $name) -isnot [bool]) { throw 'Checkpoint is missing typed control flags.' }
    }
    $hidden = Get-TVField $value 'documentHidden'
    if ($hidden -isnot [bool]) { throw 'Checkpoint is missing page visibility.' }
    $digests = @{}
    foreach ($name in @('channelSetSha256', 'layoutSha256', 'nativeAudioSha256')) {
        $digest = Get-TVField $value $name
        if ($null -ne $digest -and [string]$digest -notmatch '^[a-f0-9]{64}$') { throw 'Invalid checkpoint digest.' }
        $digests[$name] = $digest
    }
    $hosts = @()
    foreach ($hostItem in @(Get-TVField $value 'frameHosts' @())) {
        $hostName = [string](Get-TVField $hostItem 'host')
        $hostCount = [int](Get-TVField $hostItem 'count' 0)
        if ($hostName -match '^[a-zA-Z0-9.-]{1,253}$' -and $hostCount -ge 0 -and $hostCount -le 256) {
            $hosts += [ordered]@{ host = $hostName; count = $hostCount }
        }
    }
    $native = Get-TVField $value 'nativeMedia'
    $nativeOutput = [ordered]@{}
    foreach ($name in @('count', 'playing', 'paused', 'errored', 'muted', 'audible')) {
        $number = [int](Get-TVField $native $name 0)
        if ($number -lt 0 -or $number -gt 1024) { throw 'Invalid native media count.' }
        $nativeOutput[$name] = $number
    }
    return [ordered]@{
        schema = 'umininn-tv-performance-checkpoint/1'
        createdAt = $stamp.ToString('o')
        userscriptVersion = $version
        controls = [ordered]@{ audioFocus = $flags.audioFocus; unifiedAudio = $flags.unifiedAudio }
        page = $uri.GetLeftPart([UriPartial]::Path)
        browserUserAgent = ([string](Get-TVField $value 'browserUserAgent')).Substring(0, [Math]::Min(400, ([string](Get-TVField $value 'browserUserAgent')).Length))
        documentHidden = $hidden
        tileCount = [int]$count
        channelSetSha256 = $digests.channelSetSha256
        layoutSha256 = $digests.layoutSha256
        nativeAudioSha256 = $digests.nativeAudioSha256
        nativeMedia = $nativeOutput
        frameHosts = $hosts
        limitations = 'Cross-origin media playback and video frame rate cannot be read by this one-shot page checkpoint.'
    }
}

function Test-TVCheckpoint {
    param($Checkpoint, [ValidateSet('off', 'on')][string]$Mode, [ValidateSet('Firefox', 'Chrome', 'Edge')][string]$Browser, [DateTime]$EarliestUtc, [string]$ExpectedOnVersion)
    $issues = New-Object System.Collections.Generic.List[string]
    if ([DateTime]::Parse($Checkpoint.createdAt).ToUniversalTime() -lt $EarliestUtc) { $issues.Add('檢查檔太舊，請在觀看頁重新匯出。') }
    if ([DateTime]::Parse($Checkpoint.createdAt).ToUniversalTime() -gt [DateTime]::UtcNow.AddMinutes(2)) { $issues.Add('檢查檔時間在未來，請檢查系統時間後重新匯出。') }
    $hasScript = ($null -ne $Checkpoint.userscriptVersion)
    $hasControls = $Checkpoint.controls.audioFocus -or $Checkpoint.controls.unifiedAudio
    if ($Mode -eq 'off' -and ($hasScript -or $hasControls)) { $issues.Add('關閉階段仍偵測到 userscript／播放控制；請停用腳本並重新整理觀看頁。') }
    if ($Mode -eq 'on' -and (-not $hasScript -or -not $hasControls)) { $issues.Add('開啟階段未偵測到有效 userscript／播放控制。') }
    if ($Mode -eq 'on' -and $ExpectedOnVersion -and $Checkpoint.userscriptVersion -ne $ExpectedOnVersion) { $issues.Add(('腳本版本應為 {0}，目前是 {1}。' -f $ExpectedOnVersion, $Checkpoint.userscriptVersion)) }
    if ($Checkpoint.documentHidden) { $issues.Add('檢查時觀看分頁不在前景；請切到觀看頁再匯出。') }
    $ua = [string]$Checkpoint.browserUserAgent
    $matchesBrowser = switch ($Browser) {
        'Firefox' { $ua -match 'Firefox/' }
        'Chrome' { $ua -match 'Chrome/' -and $ua -notmatch 'Edg/' }
        'Edge' { $ua -match 'Edg/' }
    }
    if (-not $matchesBrowser) { $issues.Add('檢查檔的瀏覽器與所選瀏覽器不符。') }
    return @($issues.ToArray())
}

function Get-TVComparison {
    param($Run)
    $reasons = New-Object System.Collections.Generic.List[string]
    if ($Run.phases.Count -lt 2) { $reasons.Add('尚未完成兩個階段。'); return [ordered]@{ comparable = $false; reasons = @($reasons.ToArray()) } }
    $off = $Run.phases[0]
    $on = $Run.phases[1]
    foreach ($phase in @($off, $on)) {
        if ($phase.status -ne 'complete') { $reasons.Add(('階段 {0} 未完成。' -f $phase.mode)) }
        if ($null -eq $phase.summary -or $phase.summary.noBrowserSamples -gt 0) { $reasons.Add('採樣期間曾找不到瀏覽器。') }
        if ($null -ne $phase.summary -and -not $phase.summary.longDuration) { $reasons.Add('採樣少於 10 分鐘，只適合作工具／短測驗證。') }
        if ($null -ne $phase.summary -and $phase.summary.samplingGaps -gt 0) { $reasons.Add('採樣有長時間中斷，可能曾睡眠或系統忙碌。') }
        if ($null -ne $phase.summary -and $phase.summary.unreadableProcessObservations -gt 0) { $reasons.Add('有瀏覽器程序未能讀取，總量可能不完整。') }
        if ($null -ne $phase.summary -and $phase.summary.unmatchedExistingProcessObservations -gt 0) { $reasons.Add('部分程序出現時無法確認前段 CPU 基線，CPU 總量可能少算。') }
        if ($null -eq $phase.startCheckpoint -or $null -eq $phase.endCheckpoint) { $reasons.Add('缺少開始／結束階段檢查檔。') }
    }
    $checkpoints = @($off.startCheckpoint, $off.endCheckpoint, $on.startCheckpoint, $on.endCheckpoint)
    if (@($checkpoints | Where-Object { $null -eq $_ }).Count -eq 0) {
        $counts = @($checkpoints | ForEach-Object { $_.tileCount } | Select-Object -Unique)
        if ($counts.Count -ne 1) { $reasons.Add('四個檢查點的台數不同。') }
        foreach ($name in @('channelSetSha256', 'layoutSha256', 'nativeAudioSha256')) {
            $hashes = @($checkpoints | ForEach-Object { $_[$name] } | Select-Object -Unique)
            if ($hashes.Count -ne 1 -or -not $hashes[0]) { $reasons.Add(('頻道／佈局／原生音量檢查不一致或未能驗證：{0}' -f $name)) }
        }
        foreach ($name in @('count', 'playing', 'paused', 'errored', 'muted', 'audible')) {
            $values = @($checkpoints | ForEach-Object { $_.nativeMedia[$name] } | Select-Object -Unique)
            if ($values.Count -ne 1) { $reasons.Add(('原生媒體狀態在四個檢查點不同：{0}' -f $name)) }
        }
        $frameSignatures = @($checkpoints | ForEach-Object {
            (@($_.frameHosts) | Sort-Object { $_.host } | ForEach-Object { '{0}:{1}' -f $_.host, $_.count }) -join '|'
        } | Select-Object -Unique)
        if ($frameSignatures.Count -ne 1) { $reasons.Add('四個檢查點的外站頁框主機／數量不同，可能有播放器離線、移除或重新載入。') }
        if ($off.startCheckpoint.userscriptVersion -or $off.endCheckpoint.userscriptVersion) { $reasons.Add('關閉階段的腳本狀態不正確。') }
        if (-not $on.startCheckpoint.userscriptVersion -or $on.startCheckpoint.userscriptVersion -ne $on.endCheckpoint.userscriptVersion) { $reasons.Add('開啟階段的腳本版本改變或缺失。') }
    }
    $delta = $null
    if ($null -ne $off.summary -and $null -ne $on.summary) {
        if ([Math]::Abs($on.summary.actualSampledSeconds - $off.summary.actualSampledSeconds) -gt (0.05 * [Math]::Max($off.summary.actualSampledSeconds, $on.summary.actualSampledSeconds))) { $reasons.Add('兩段採樣長度相差超過 5%。') }
        $delta = [ordered]@{
            cpuCorePercentagePoints = [Math]::Round($on.summary.cpuCorePercent - $off.summary.cpuCorePercent, 3)
            cpuHostCapacityPercentagePoints = [Math]::Round($on.summary.cpuHostCapacityPercent - $off.summary.cpuHostCapacityPercent, 3)
            averagePrivateMiB = [Math]::Round($on.summary.averagePrivateMiB - $off.summary.averagePrivateMiB, 3)
            averageWorkingSetMiB = [Math]::Round($on.summary.averageWorkingSetMiB - $off.summary.averageWorkingSetMiB, 3)
        }
    }
    return [ordered]@{
        comparable = ($reasons.Count -eq 0)
        reasons = @($reasons.ToArray())
        onMinusOff = $delta
        caution = 'Sequential live-site A/B is observational: ads, stream quality, hardware acceleration and background work can differ. These process totals cannot prove that every difference is caused by the userscript.'
    }
}

function ConvertTo-TVHtml {
    param($Run)
    Add-Type -AssemblyName System.Web
    $encode = { param($text) [Web.HttpUtility]::HtmlEncode([string]$text) }
    $bodyRows = ''
    foreach ($phase in $Run.phases) {
        $summary = $phase.summary
        if ($null -eq $summary) { continue }
        $cells = @($phase.mode, $phase.status, $summary.actualSampledSeconds, $summary.cpuCorePercent, $summary.cpuHostCapacityPercent, $summary.averagePrivateMiB, $summary.privateGrowthMiB, $summary.peakPrivateMiB)
        $bodyRows += '<tr>' + (($cells | ForEach-Object { '<td>' + (& $encode $_) + '</td>' }) -join '') + '</tr>'
    }
    $state = if ($Run.comparison.comparable) { '檢查點一致，可作觀察性對照' } else { '有條件差異，請先查看原因' }
    $issues = (@($Run.comparison.reasons) | ForEach-Object { '<li>' + (& $encode $_) + '</li>' }) -join ''
    $delta = ''
    if ($null -ne (Get-TVField $Run.comparison 'onMinusOff')) { $delta = '<pre>' + (& $encode ($Run.comparison.onMinusOff | ConvertTo-Json)) + '</pre>' }
    return '<!doctype html><html lang="zh-HK"><meta charset="utf-8"><title>Umininn TV 實機效能結果</title><style>body{font:16px/1.65 system-ui;max-width:1100px;margin:32px auto;padding:0 18px;color:#17202a}table{border-collapse:collapse;width:100%}th,td{padding:8px;border:1px solid #b8c2cc;text-align:right}th:first-child,td:first-child{text-align:left}pre{background:#eef2f5;padding:12px;overflow:auto}.note{color:#526170}</style><h1>Umininn TV 實機效能結果</h1><p>瀏覽器：' + (& $encode $Run.browser) + '；邏輯 CPU：' + (& $encode $Run.hostInfo.logicalCpuCount) + '</p><p><strong>' + (& $encode $state) + '</strong></p><ul>' + $issues + '</ul><table><thead><tr><th>階段</th><th>狀態</th><th>實測秒</th><th>CPU %（一核心=100）</th><th>全機容量 %</th><th>平均 Private MiB</th><th>Private 增長 MiB</th><th>Private 峰值 MiB</th></tr></thead><tbody>' + $bodyRows + '</tbody></table><h2>開啟減去關閉</h2>' + $delta + '<p class="note">量測整個所選瀏覽器，包括其他視窗、分頁及 profiles，不是單一分頁。Private 是私有提交記憶體；Working Set 可能重複計算共用頁。記憶體上升本身不是洩漏證明。</p><p class="note">真實直播兩段可能有廣告、畫質或串流狀態差異，結果屬觀察性對照；請一併提供 summary.json、samples.csv、processes.csv 和檢查點。</p></html>'
}

function Save-TVRun {
    param($Run, [string]$Folder)
    $Run.updatedAt = [DateTime]::UtcNow.ToString('o')
    $Run.comparison = Get-TVComparison $Run
    Write-TVUtf8 (Join-Path $Folder 'summary.json') ($Run | ConvertTo-Json -Depth 14)
    Write-TVUtf8 (Join-Path $Folder 'report.html') (ConvertTo-TVHtml $Run)
}

function Invoke-TVPhase {
    param($Run, $Phase, [string]$Folder, [string[]]$ProcessNames, [double]$DurationSeconds, [double]$WarmupSeconds, [double]$SampleSeconds, [scriptblock]$SnapshotProvider, [scriptblock]$CancelCheck)
    if ($DurationSeconds -le 0 -or $SampleSeconds -le 0 -or $WarmupSeconds -lt 0) { throw 'Invalid sampling duration.' }
    if ($null -eq $SnapshotProvider) { $SnapshotProvider = { param($names) Get-TVProcessSnapshot $names } }
    if ($null -eq $CancelCheck) { $CancelCheck = { try { if ([Console]::KeyAvailable) { return ([Console]::ReadKey($true).Key -eq 'Q') } } catch {}; return $false } }
    $Phase.status = 'warming-up'
    Save-TVRun $Run $Folder
    $warm = [Diagnostics.Stopwatch]::StartNew()
    while ($warm.Elapsed.TotalSeconds -lt $WarmupSeconds) {
        if (& $CancelCheck) { $Phase.status = 'cancelled'; Save-TVRun $Run $Folder; return }
        Write-Progress -Activity '暖機：請回到觀看頁並維持前景' -Status ('剩餘約 {0} 秒；在本視窗按 Q 可停止' -f [Math]::Ceiling($WarmupSeconds - $warm.Elapsed.TotalSeconds))
        Start-Sleep -Milliseconds 200
    }
    Write-Progress -Activity '暖機：請回到觀看頁並維持前景' -Completed
    $previous = & $SnapshotProvider $ProcessNames
    $Phase.initialPrivateBytes = $previous.privateBytes
    $Phase.startedAt = [DateTime]::UtcNow.ToString('o')
    $Phase.status = 'recording'
    Save-TVRun $Run $Folder
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $next = [double]$SampleSeconds
    try {
        while ($true) {
            if (& $CancelCheck) { $Phase.status = 'cancelled'; break }
            $remaining = [Math]::Min($next, $DurationSeconds) - $watch.Elapsed.TotalSeconds
            if ($remaining -gt 0) { Start-Sleep -Milliseconds ([int][Math]::Max(1, [Math]::Min(200, $remaining * 1000))); continue }
            $current = & $SnapshotProvider $ProcessNames
            $delta = Get-TVDelta $previous $current $Run.hostInfo.logicalCpuCount
            $row = [pscustomobject][ordered]@{
                phase = $Phase.mode
                sample = $Phase.rows.Count + 1
                observedAtUtc = $current.observedAtUtc
                phaseElapsedSeconds = [Math]::Round($watch.Elapsed.TotalSeconds, 3)
                intervalSeconds = $delta.elapsedSeconds
                cpuSeconds = $delta.cpuSeconds
                cpuCorePercent = $delta.cpuCorePercent
                cpuHostCapacityPercent = $delta.cpuHostCapacityPercent
                privateBytes = $current.privateBytes
                workingSetBytes = $current.workingSetBytes
                processCount = $current.processCount
                unreadableProcesses = $current.unreadableProcesses
                newProcesses = $delta.newProcesses
                exitedProcesses = $delta.exitedProcesses
                unmatchedExistingProcesses = $delta.unmatchedExistingProcesses
            }
            $Phase.rows += $row
            $row | Export-Csv -LiteralPath (Join-Path $Folder 'samples.csv') -NoTypeInformation -Append -Encoding UTF8
            foreach ($item in $current.processes) {
                [pscustomobject][ordered]@{ phase = $Phase.mode; sample = $row.sample; observedAtUtc = $current.observedAtUtc; id = $item.id; name = $item.name; startUtc = $item.startUtc; cpuSeconds = $item.cpuSeconds; privateBytes = $item.privateBytes; workingSetBytes = $item.workingSetBytes } |
                    Export-Csv -LiteralPath (Join-Path $Folder 'processes.csv') -NoTypeInformation -Append -Encoding UTF8
            }
            $Phase.summary = Get-TVPhaseSummary $Phase $Run.hostInfo.logicalCpuCount
            Save-TVRun $Run $Folder
            Write-Progress -Activity ('採樣中：{0}' -f $Phase.mode) -Status ('{0:N0}/{1:N0} 秒；CPU {2:N1}%（一核心）；Private {3:N0} MiB；本視窗 Q 停止' -f $watch.Elapsed.TotalSeconds, $DurationSeconds, $row.cpuCorePercent, ($row.privateBytes / 1MB)) -PercentComplete ([Math]::Min(100, 100 * $watch.Elapsed.TotalSeconds / $DurationSeconds))
            $previous = $current
            $next += $SampleSeconds
            if ($watch.Elapsed.TotalSeconds -ge $DurationSeconds) { break }
        }
        if ($Phase.status -eq 'recording') { $Phase.status = 'complete' }
    } finally {
        $Phase.endedAt = [DateTime]::UtcNow.ToString('o')
        $Phase.actualWallSeconds = $watch.Elapsed.TotalSeconds
        $Phase.summary = Get-TVPhaseSummary $Phase $Run.hostInfo.logicalCpuCount
        Save-TVRun $Run $Folder
        Write-Progress -Activity ('採樣中：{0}' -f $Phase.mode) -Completed
    }
}
